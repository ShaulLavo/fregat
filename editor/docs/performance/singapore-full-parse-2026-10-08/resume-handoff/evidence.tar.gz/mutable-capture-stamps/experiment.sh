#!/usr/bin/env bash
set -euo pipefail
export PATH=$HOME/.local/share/mise/shims:$PATH
out=/work/reports/plan-339/qualification/mutable-capture-stamps-experiment
roots=(/work/worktrees/platform/plan-339-error-free-walk /work/worktrees/platform/plan-339-bracket-prefilter)
[[ ! -e "$out" ]]
mkdir -p "$out"
cmp "${roots[0]}/bun.lock" "${roots[1]}/bun.lock"
cat > "$out/classification.json" <<'CLASSIFICATION'
{
  "kind": "prospective paired diagnostic experiment, not qualification",
  "date": "2026-10-09",
  "baseline": "shipping error-free-walk candidate e68663768bee4bd3b7d7de3acbb9bc7549154406",
  "candidate": "same source plus bounded mutable capture-name span stamps, with the mutable capture stamps removed",
  "coldOrder": ["baseline", "candidate"],
  "warmOrder": ["candidate", "baseline"],
  "repetitionsPerSideAndCondition": 1,
  "condition": "quiet",
  "qualification": false,
  "hostRecipe": "archival and host-specific; not a portable committed test"
}
CLASSIFICATION
for role in baseline candidate; do
  index=0; [[ "$role" != candidate ]] || index=1
  root=${roots[$index]}
  cp "$root/editor/packages/tree-sitter/src/treeSitter/treeSitter.worker.ts" "$out/$role-treeSitter.worker.ts"
  cp "$root/editor/bench/compare/full-document.mjs" "$out/$role-full-document.mjs"
  git -C "$root" status --porcelain > "$out/$role-source-status.txt"
  bash /work/tmp/wave-heavy/run.sh --class build "plan339 mutable capture stamps $role build" -- env PATH="$PATH" bash -euo pipefail -c 'cd "$1/editor/bench/compare"; node build.mjs --full-document' _ "$root"
done
for startup in cold warm; do
  roles=(baseline candidate); extra=()
  [[ "$startup" != warm ]] || { roles=(candidate baseline); extra=(--warm); }
  for role in "${roles[@]}"; do
    index=0; [[ "$role" != candidate ]] || index=1
    bash /work/tmp/quiet-turn.sh "plan339 mutable capture stamps diagnostic $startup $role" --class bench -- env PATH="$PATH" PLAYWRIGHT_BROWSERS_PATH=/work/cache/ms-playwright bash -euo pipefail -c 'exec 9>/work/tmp/wave-heavy/admission.lock; flock 9; cd "$1/editor/bench/compare"; shift; node run.mjs "$@"' _ "${roots[$index]}" --profile-open --open-only --full-document --sizes 10 --editors singapore --repetitions 1 --timeout 60000 --condition quiet --output "$out/$startup/$role" "${extra[@]}"
  done
  node "${roots[0]}/editor/bench/compare/summarize-open.mjs" "$out/$startup/candidate/experiment.json" --compare "$out/$startup/baseline/experiment.json" > "$out/$startup-comparison.json"
done
python3 /work/reports/plan-339/qualification/derive-error-free-walk.py "$out" /work/reports/plan-339/qualification/capture-consumer-published-smoke/experiment.json
