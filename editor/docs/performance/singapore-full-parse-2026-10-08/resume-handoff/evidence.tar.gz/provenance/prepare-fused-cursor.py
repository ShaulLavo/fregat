from pathlib import Path

root = Path('/work/worktrees/platform/plan-339-bracket-prefilter')
baseline = Path('/work/worktrees/platform/plan-339-error-free-walk')
worker = 'editor/packages/tree-sitter/src/treeSitter/treeSitter.worker.ts'
(root / worker).write_bytes((baseline / worker).read_bytes())
p = root / 'editor/bench/compare/full-document.mjs'
original = p.read_text()
Path('/work/reports/plan-339/qualification/fused-cursor-original-full-document.mjs').write_text(original)
runtime = """  if (id.endsWith('/web-tree-sitter/web-tree-sitter.js')) {
    return replaceRequired(code, '  gotoNextSibling() {', `  gotoNext() {
    marshalTreeCursor(this);
    try {
      if (C._ts_tree_cursor_goto_first_child_wasm(this.tree[0]) === 1) return true;
      if (C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]) === 1) return true;
      while (C._ts_tree_cursor_goto_parent_wasm(this.tree[0]) === 1) {
        if (C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]) === 1) return true;
      }
      return false;
    } finally {
      unmarshalTreeCursor(this);
    }
  }
  gotoNextSibling() {`)
  }
"""
old = """  while (true) {
    collectCursorDiagnostics(cursor, visitors, bracketStack, hasErrors)

    if (cursor.gotoFirstChild()) continue
    if (cursor.gotoNextSibling()) continue

    while (true) {
      if (!cursor.gotoParent()) return
      if (cursor.gotoNextSibling()) break
    }
  }
"""
new = """  do {
    collectCursorDiagnostics(cursor, visitors, bracketStack, hasErrors)
  } while (cursor.gotoNext())
"""
assert original.count('export function fullDocumentTransform(code, id) {') == 1
s = original.replace('export function fullDocumentTransform(code, id) {',
                     'export function fullDocumentTransform(code, id) {\n' + runtime)
needle = "  if (id.endsWith('/tree-sitter/src/treeSitter/treeSitter.worker.ts')) {"
assert s.count(needle) == 1
s = s.replace(needle, needle + '\n    code = replaceRequired(code, ' + repr(old) + ', ' + repr(new) + ')\n')
p.write_text(s)
s = Path('/work/reports/plan-339/qualification/bracket-prefilter-experiment.sh').read_text()
s = s.replace('bracket-prefilter-experiment', 'fused-cursor-experiment')
s = s.replace('single-character prefilter before bracket set lookups',
              'experiment-only full-walk gotoNext using one marshal/unmarshal pair and unchanged native movement functions')
s = s.replace('bracket prefilter', 'fused cursor')
Path('/work/reports/plan-339/qualification/fused-cursor-experiment.sh').write_text(s)
